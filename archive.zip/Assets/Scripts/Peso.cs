using UnityEngine;

public class Peso : MonoBehaviour
{
    public int PesoObj;

}
