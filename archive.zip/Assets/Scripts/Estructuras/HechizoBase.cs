using System;
using UnityEngine;
[Serializable]
public abstract class HechizoBase 
{
    public int Patata;
}

public class BolaDeFuego: HechizoBase
{

}
