public struct IdiomaObjetos 
{
    public static string CuboAmarillo = "Cubo Amarillo";
    public static string Moneda = "Moneda";
    public static string EspadaCorta = "EspadaCorta";
    public static string Antorcha = "Antorcha";
    public static string ObjetoVacio = "ObjetoVacio";

    //por cada cubo crear una linea
}