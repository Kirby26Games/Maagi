public struct IdiomaObjetos 
{
    public static string CuboAmarillo = "Cubo Amarillo";
}