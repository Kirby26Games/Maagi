using UnityEngine;

public class AtaquePersonaje : MonoBehaviour
{
    public bool PuedoAtacar;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
