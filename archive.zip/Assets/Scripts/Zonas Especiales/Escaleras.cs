using UnityEngine;

public class Escaleras : MonoBehaviour
{
    public int VelocidadSubirEscalera = 2;
}
