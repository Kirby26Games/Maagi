using UnityEngine;

public class EscaleraSimple : MonoBehaviour
{
    
}
