using System.Collections.Generic;
using UnityEngine;

public class InventarioBase : MonoBehaviour
{
    public List<Objeto> ObjetosInventario;

    //Operaciones para InventarioPersonaje
}
