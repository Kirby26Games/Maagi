using UnityEngine;

public class ObjetoEscena : MonoBehaviour
{
    public int ID;
    public string Nombre;
    public int Cantidad = 1;

}

