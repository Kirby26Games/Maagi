using UnityEngine;

public class ObjetoEscena : MonoBehaviour
{
    public Objeto Objeto;

}

